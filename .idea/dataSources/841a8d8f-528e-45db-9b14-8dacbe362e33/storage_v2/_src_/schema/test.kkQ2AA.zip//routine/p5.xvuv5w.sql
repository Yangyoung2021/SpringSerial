create
    definer = root@localhost procedure p5(IN start_num int, IN end_num int)
BEGIN
	DECLARE RESULT int DEFAULT 0;
	REPEAT 
		SET RESULT = RESULT + start_num;
		SET start_num = start_num + 1;
	until end_num < start_num
	END REPEAT;
	SELECT RESULT;
END;

