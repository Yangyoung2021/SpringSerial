create
    definer = root@localhost procedure p1(IN count int)
BEGIN
	DECLARE num int;
	DECLARE n varchar(10);
	REPEAT  
		SET num = round(rand()*1000000);
		SET n = (CASE 
			WHEN mod(num, 4) = 3 THEN '张三'
			WHEN mod(num, 4) = 2 THEN '里斯'
			WHEN mod(num, 4) = 1 THEN '王五'
			ELSE '赵六'
		END);
			INSERT INTO emp
			(id, e_name, age)
			VALUES(num, n  , MOD(num, 100) + 1);
		SET count = count - 1;
	until count < 0	END REPEAT;
END;

